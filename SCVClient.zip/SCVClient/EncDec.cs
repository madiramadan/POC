using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System;  
using System.IO;  
using System.Security.Cryptography;  
using System.Text;

namespace SCVClient
{
	class EncDec
	{
		public static void EncryptString(string sourcepath, string encryptedpath)
		{			
			var key = generateguid().Replace("-", "");			
			string encryptkey = encryptrsakey(key);
			writeaeskey(encryptkey);						
			byte[] iv = new byte[16];			
			using (Aes aes = Aes.Create())
			{
				aes.Key = Encoding.UTF8.GetBytes(key);
				aes.IV = iv;
				ICryptoTransform encryptor = aes.CreateEncryptor(aes.Key, aes.IV);				
				using (FileStream plain = File.Open(sourcepath, FileMode.Open, FileAccess.Read, FileShare.Read))
				{
					using (FileStream encrypted = File.Open(encryptedpath, FileMode.Create, FileAccess.Write, FileShare.None))
					{
						using (CryptoStream cs = new CryptoStream(encrypted, encryptor, CryptoStreamMode.Write))
						{
							plain.CopyTo(cs);
						}
					}
				}
			}						
		}
		public static void writetofile(string decontent, string path)
		{
			if (File.Exists(path))
			{
				File.Delete(path);
			}

			using (FileStream fs = File.Create(path))
			{
				Byte[] title = new UTF8Encoding(true).GetBytes(decontent);
				fs.Write(title, 0, title.Length);
			}
		}
		public static void writeaeskey(string aeskey)
		{			
			string plainText = "SCV RINGKAS|" + DateTime.Now.ToString() + "|" + aeskey;
			writetofile(plainText, "E:\\EncDec\\Encrypt\\SCV RINGKAS HEADER PACKAGE.txt");
		}
		public static string readaeskey()
		{
			Stream fs = File.OpenRead("E:\\EncDec\\Encrypt\\SCV RINGKAS HEADER PACKAGE.txt");
			string plainText = ToEncodedString(fs, null);
			fs.Close();
			fs.Dispose();
			char[] splitter = { '|' };
			string[] deaeskey = plainText.Split(splitter);		
			return deaeskey[2];			
		}
		public static String ToEncodedString(Stream stream, Encoding enc = null)
		{
			//enc = enc ?? Encoding.UTF8;
			enc = Encoding.UTF8;
			byte[] bytes = new byte[stream.Length];
			stream.Position = 0;
			stream.Read(bytes, 0, (int)stream.Length);
			string data = enc.GetString(bytes);

			return enc.GetString(bytes);
		}
		public static byte[] ReadToEnd(System.IO.Stream stream)
		{
			long originalPosition = 0;

			if (stream.CanSeek)
			{
				originalPosition = stream.Position;
				stream.Position = 0;
			}

			try
			{
				byte[] readBuffer = new byte[4096];

				int totalBytesRead = 0;
				int bytesRead;

				while ((bytesRead = stream.Read(readBuffer, totalBytesRead, readBuffer.Length - totalBytesRead)) > 0)
				{
					totalBytesRead += bytesRead;

					if (totalBytesRead == readBuffer.Length)
					{
						int nextByte = stream.ReadByte();
						if (nextByte != -1)
						{
							byte[] temp = new byte[readBuffer.Length * 2];
							Buffer.BlockCopy(readBuffer, 0, temp, 0, readBuffer.Length);
							Buffer.SetByte(temp, totalBytesRead, (byte)nextByte);
							readBuffer = temp;
							totalBytesRead++;
						}
					}
				}

				byte[] buffer = readBuffer;
				if (readBuffer.Length != totalBytesRead)
				{
					buffer = new byte[totalBytesRead];
					Buffer.BlockCopy(readBuffer, 0, buffer, 0, totalBytesRead);
				}
				return buffer;
			}
			finally
			{
				if (stream.CanSeek)
				{
					stream.Position = originalPosition;
				}
			}
		}
		public static void DecryptString(string encryptedpath, string decryptedpath)
		{						
			string plainText = readaeskey();
			var key = decryptrsakey(plainText);						
			byte[] iv = new byte[16];								
			using (Aes aes = Aes.Create())
			{
				aes.Key = Encoding.UTF8.GetBytes(key);
				aes.IV = iv;
				ICryptoTransform decryptor = aes.CreateDecryptor(aes.Key, aes.IV);
				using (FileStream plain = File.Open(decryptedpath, FileMode.Create, FileAccess.Write, FileShare.None))
				{
					using (FileStream encrypted = File.Open(encryptedpath, FileMode.Open, FileAccess.Read, FileShare.Read))
					{
						using (CryptoStream cs = new CryptoStream(plain, decryptor, CryptoStreamMode.Write))
						{
							encrypted.CopyTo(cs);
						}
					}
				}				
			}
		}
		public static string generateguid()
		{
			string deguid = "";
			Guid obj = Guid.NewGuid();
			deguid = obj.ToString();
			return deguid;
		}
		public static string encryptrsakey(string plainTextData)
		{
			var csp = new RSACryptoServiceProvider(2048);
			var pubKeyString = "<?xml version=\"1.0\" encoding=\"utf-16\"?>\r\n<RSAParameters xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\">\r\n  <Exponent>AQAB</Exponent>\r\n  <Modulus>jKN/rFDrW02ZpleD88Yn1X2CJGxjDzjDlrnNl95u+4KY2JMF0SSbHhjeCND2GgGp/9/m0r7TZAJBFhf4y7dvHgmbL+DxHc7pNK9D9lFqaouPNNiHPTux1IABQ/H6rR+Z7dlds57TjIuxjzcyw/UmJS2FqSrXg0Th5EwEng1ElSGa7McWSoTnwJwbUlvKtt2SK2O4RyG9KugChl/z3Vt2G6Oo6zMC48FnQY27CDtgJbKXblvWxHwnqiXa4+uLKhHZZZuMJFirUIXlxt2bWgzRa0k/GWfLBr1RdbMbl/NYk4uatahKzHnOeEV04nwvBN1swLyJI5Q/tgXGT+/Hh4gxrw==</Modulus>\r\n</RSAParameters>";
			var sr = new System.IO.StringReader(pubKeyString);
			var xs = new System.Xml.Serialization.XmlSerializer(typeof(RSAParameters));
			var pubKey = (RSAParameters)xs.Deserialize(sr);			
			csp = new RSACryptoServiceProvider();
			csp.ImportParameters(pubKey);
			var bytesPlainTextData = System.Text.Encoding.Unicode.GetBytes(plainTextData);
			var bytesCypherText = csp.Encrypt(bytesPlainTextData, false);
			var cypherText = Convert.ToBase64String(bytesCypherText);
			return cypherText;
		}
		public static string decryptrsakey(string cypherText)
		{
			var csp = new RSACryptoServiceProvider(2048);
			string privKeyString = "<?xml version=\"1.0\" encoding=\"utf-16\"?>\r\n<RSAParameters xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\">\r\n  <Exponent>AQAB</Exponent>\r\n  <Modulus>jKN/rFDrW02ZpleD88Yn1X2CJGxjDzjDlrnNl95u+4KY2JMF0SSbHhjeCND2GgGp/9/m0r7TZAJBFhf4y7dvHgmbL+DxHc7pNK9D9lFqaouPNNiHPTux1IABQ/H6rR+Z7dlds57TjIuxjzcyw/UmJS2FqSrXg0Th5EwEng1ElSGa7McWSoTnwJwbUlvKtt2SK2O4RyG9KugChl/z3Vt2G6Oo6zMC48FnQY27CDtgJbKXblvWxHwnqiXa4+uLKhHZZZuMJFirUIXlxt2bWgzRa0k/GWfLBr1RdbMbl/NYk4uatahKzHnOeEV04nwvBN1swLyJI5Q/tgXGT+/Hh4gxrw==</Modulus>\r\n  <P>wUVNK0tNXs5vfxgxmlH7+ihtZWzb5YOmEi6WgEoXDrwQNZOhXhtHyaRc/CgJwSy5ZSPRDYhCvkOg84jsSORO3voyGtud/UiwArqOysT+T2TXCZNTjhNSNPEXzmf7nTXqeF7tCsNrj29TPrHLruH29GXcL+9ESvpAzofepjxS7k0=</P>\r\n  <Q>ukkLtqCjwrGAC62aMBLde/fgbF7jo2JXK9lsAgMMjsPbv3eGpncCwL2WDELujBiAHpKeXP8ZUxYKQovWUovs2wGUgtNJFIZCmiasc+WB7UWrdX9xyi0gSzpaIVgzh3YNS+bV/HwaGIqMVI6u3cMsHNi8Zuz4Dj/zHN4OyowXtes=</Q>\r\n  <DP>R4acPo+JvLJtdP3BLbl1pWjcw5J79v63sTbon+XLjrpuzUUrjSZPdQKNHwy6P3GL0zBkJ7vr53oj0L01pOxJfB/f9yyb1abW7MuaGNS6wSsyoeqSG5xu6gTnqI23AsF3WsDWvQsBfX3XsvYdyUT7HgusZ1kHTzA6V7TU43SjxGk=</DP>\r\n  <DQ>YqK8xgWG0FcF8qkIRD4o8jQMq7UOmXs/puMn0mTk6E8Ccv4J2OiZF48K/REPmDR82jNOEPWt5hV8d0HtyKV4U3ohtafEQU7Zwx+JHpC+W/EQ2VUS3jdIqyyJfrBiEG7MmYzvbxITCz2JEli+dIOcPuXv1BvTOFBaHMXjVRIal+M=</DQ>\r\n  <InverseQ>I3gPswfKuGuoMZZVVZqCD0r+6lm1s3pea8ajC/3nMdj1i/kSpBsNpw4AhU6MDQMRwCbcZdF2THPUf3Sj834f/TdAcwrgN6PNR8bY/4dk66hT9ipNARKysYtmC5EzMaKiOcm9wLaJf0R0kYjDRjnbJW9yAeHPv7mrKsxlf0wSSMs=</InverseQ>\r\n  <D>FVfD9V47tBnHr+MSHE7oa/wQYaoCh88r0iuU/sTRKja8hAlz1YnCR0QA1hetcW7qjJvpsfZ8VW4I0JXcukBhNY7BpUzJaqZO5SGVT8Pf7Ba31I4+SoBM/Bxc6iHGfWVmp8jX8SgGSgrybEiKhLXRucykacgdopyJJ2s95s/JUP7p+RutCOP7hIRrqgPkeI3fxPLoN7XvNrzmCu3wC7Hd8RZkzs2m9gKdgbWUAPeqiAmigMP5Una/IYGAkgulWG9ynvijI4w/foGKi4bN8roujOmHP2UsboPw1QhPjf6xiHr6t5/Jq5IVvBLcC15HdP2ZYNucVfq0o0/KnWleHsIZCQ==</D>\r\n</RSAParameters>";
			var sr = new System.IO.StringReader(privKeyString);
			var xs = new System.Xml.Serialization.XmlSerializer(typeof(RSAParameters));
			var privKey = (RSAParameters)xs.Deserialize(sr);			
			var bytesCypherText = Convert.FromBase64String(cypherText);
			csp = new RSACryptoServiceProvider();
			csp.ImportParameters(privKey);
			var bytesPlainTextData = csp.Decrypt(bytesCypherText, false);
			var plainTextData = System.Text.Encoding.Unicode.GetString(bytesPlainTextData);
			return plainTextData;
		}
	}
}
