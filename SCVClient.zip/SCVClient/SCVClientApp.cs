using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace SCVClient
{
    public partial class SCVClientApp : Form
    {
        public SCVClientApp()
        {
            InitializeComponent();
			//MessageBox.Show("Set Permission", "Set Permission", MessageBoxButtons.OK);
			//CheckVersion.setfolderperm();
			//if (CheckVersion.checkupdateversion(0))
			//{
			//	MessageBox.Show("Need Update", "Version Update", MessageBoxButtons.OK);
			//	if (CheckVersion.downloadfile())
			//	{
			//		MessageBox.Show("Download Sukses", "Download File", MessageBoxButtons.OK);
			//		CheckVersion.runinstaller();
			//		System.Environment.Exit(0);
			//	}
			//}
			//else
			//{
			//	MessageBox.Show("No Need Update", "Version Update", MessageBoxButtons.OK);
			//}
		}

		private void Encrypt_Click(object sender, EventArgs e)
		{			
			EncDec.EncryptString("E:\\EncDec\\Original\\fileclient.txt.gz", "E:\\EncDec\\Encrypt\\fileclient.txt.gz");						
		}

		private void Decrypt_Click(object sender, EventArgs e)
		{			
			EncDec.DecryptString("E:\\EncDec\\Encrypt\\fileclient.txt.gz", "E:\\EncDec\\Decrypt\\fileclient.txt.gz");			
		}
	}
}
