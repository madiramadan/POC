using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SCVClient.ServiceReference1;
using System.IO;
using System.Net;
using System.Diagnostics;
using System.Windows.Forms;
using System.Security.AccessControl;
using System.Security.Principal;

namespace SCVClient
{
	class CheckVersion
	{
		public static void setfolderperm()
		{
			try
			{
				string appPath = Path.GetDirectoryName(Application.ExecutablePath);
				string file = appPath + "\\NewVersion"; ;
				DirectoryInfo dInfo = new DirectoryInfo(file);
				DirectorySecurity dSecurity = dInfo.GetAccessControl();
				dSecurity.AddAccessRule(new FileSystemAccessRule(new SecurityIdentifier(WellKnownSidType.WorldSid, null), FileSystemRights.FullControl, InheritanceFlags.ObjectInherit | InheritanceFlags.ContainerInherit, PropagationFlags.NoPropagateInherit, AccessControlType.Allow));
				dInfo.SetAccessControl(dSecurity);
			}
			catch(Exception ex)
			{
				
			}
		}
		
		public static Boolean checkupdateversion(int currversion)
		{
			ServiceReference1.CheckVersionClient desvc = new CheckVersionClient();			
			return bool.Parse(desvc.GetData(currversion));
		}

		public static bool downloadfile()
		{
			bool issukses = false;
			using (WebClient wc = new WebClient())
			{
				//wc.DownloadProgressChanged += wc_DownloadProgressChanged;
				string appPath = Path.GetDirectoryName(Application.ExecutablePath);
				try
				{
					wc.DownloadFile(
						new System.Uri("http://localhost/proposal/assets/ClientSCVAppInstaller.msi"),
						appPath + "\\NewVersion\\ClientSCVAppInstaller.msi"
					);
				}
				catch(Exception ex)
				{
					wc.DownloadFile(
						new System.Uri("http://localhost/proposal/assets/ClientSCVAppInstaller.msi"),
						appPath + "\\ClientSCVAppInstaller.msi"
					);
				}
				issukses = true;
			}
			return issukses;
		}

		public static void runinstaller()
		{
			string appPath = Path.GetDirectoryName(Application.ExecutablePath);
			try
			{
				Process.Start(appPath + "\\NewVersion\\ClientSCVAppInstaller.msi");
			}
			catch(Exception ex)
			{
				Process.Start(appPath + "\\ClientSCVAppInstaller.msi");
			}			
		}

		public static void wc_DownloadProgressChanged(object sender, DownloadProgressChangedEventArgs e)
		{
			//progressBar.Value = e.ProgressPercentage;
		}
	}
}
